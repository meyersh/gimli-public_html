#ifndef RANDOMSTR_HPP
#define RANDOMSTR_HPP

#include <string>

using namespace std;

void randomString(string &rstr, int slen, 
const string 
&basechars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");

#endif

